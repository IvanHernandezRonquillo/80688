import { TextField, Button, Box } from "@mui/material";
import React,{useEffect, useState} from "react";

function Formulario(props){
    const procesarFormulario = (evento)=> {
        evento.preventDefault()
        console.log(evento)        
    }
    return (
        <>
            <h1>Inicio de Sesión</h1>
            <from onSumit={procesarFormulario}>
                <Box m={5}>
                    <TextField label="Nombre:" variant="outlined" fullWidth></TextField>
                </Box>
                <Box m={5}>
                    <TextField label="Contraseña" variant="outlined" type="password" fullWidth></TextField>
                </Box>
                <Box m={5}>
                    <Button variant="contained" type="submit" color="primary" fullWidth>Iniciar Sesión</Button>
                </Box>
            </from>
        </>
    )
}
export default Formulario